/* Lab #1						Hayden Lepla
120-06							9/3/2015

*/

#include <iostream> // include the header with I/0 commands

using namespace std;

int main()					//beginning of the program

{

	cout << "Hello, world!" << endl; // print some output

	return 0;

}
