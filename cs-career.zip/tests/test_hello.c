#include<stdio.h>

int main()
{

  printf("Hello World ") ;
  putchar('\n') ;

  return 0 ;


}
