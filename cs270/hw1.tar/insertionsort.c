/* insertionsort.c */
 
#include <stdio.h>
 
int insertionsort(int array[])
{
  int c, d, t;
 
  for (c = 1 ; c <= 9 - 1; c++) {
    d = c;
 
    while ( d > 0 && array[d] < array[d-1]) {
      t          = array[d];
      array[d]   = array[d-1];
      array[d-1] = t;
 
      d--;
    }
  }
 
  printf("Sorted list in ascending order(insertionsort):\n");
 
  for (c = 0; c <= 9 - 1; c++) {
    printf("%d\n", array[c]);
  }
 

}
