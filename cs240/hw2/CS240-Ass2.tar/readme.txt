/* Readme.txt */

NAME:

  msh (my shell)

DESCRIPTION:

  Basic shell that runs various programs and limited shell operations.
  The shell will support more features over time. 

INSTALLATION AND EXECUTION:

  To complie source file, type  "gcc msh.c -o msh" without the quotes.
  To run the executable, type "./msh" without the quotes.

RELEASED VERSIONS:

  V 1.0

AUTHOR:

  Created by Hayden Lepla

REPORTING BUGS:

  Report all bugs to lepl1529@vandals.uidaho.edu

COPYRIGHT:

  This is free software: you are free to change and redistribute it.
  There is NO WARRANTY, to the extent permitted by law.
