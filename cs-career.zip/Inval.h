#include <string>

using namespace std ;

class Inval {

 private:
  int inbase ;
  string data ;
  int decimaldata ;
 public:

 void PrintAsBase();
 void convertdecimal();
 void setinput_base(int );
 void setinput_Num (string ) ; 
 
};
