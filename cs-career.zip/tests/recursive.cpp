#include <iostream>

using namespace std;


int main()
{
  int x, y ;


  x=3 ;

  y=7 ;


  for(int i=0 ; i <= 1000000 ; i++)
    {

      cout <<"x: " << x << "y: " << y << endl ;
      //      cout << endl;

      x + y ;



    }


  return 0;  


}
