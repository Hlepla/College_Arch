/* bubblesort.c*/

#include <stdio.h>

int bubblesort(int array[])
{
  int  c, d, swap;

  for (c = 0 ; c < ( 9 - 1 ); c++)
    {
      for (d = 0 ; d < 9 - c - 1; d++)
        {
          if (array[d] > array[d+1]) /* For decreasing order use < */
            {
              swap       = array[d];
              array[d]   = array[d+1];
              array[d+1] = swap;
            }
        }
    }

  printf("Sorted list in ascending order(bubblesort):\n");

  for ( c = 0 ; c < 9 ; c++ )
    printf("%d\n", array[c]);


}
