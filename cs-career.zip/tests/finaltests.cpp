#include <iostream>

using namespace std;


int main(){

  int ia = 3 , ib = 4 , ic =6 ;
  float fa = 3.0 , fb =4.0 , fc =8.0 ;
  int id, ie ;
  float fd, fe ;

  ie = fa / fb * fc ;

  cout << ie << endl ;

}
