/*
  quicksort.c

 */

#include <stdio.h>

void printfunc(int a[]) ;
int partition( int[], int, int);

// quickSort( a, 0, 8);




int quicksort( int a[], int l , int r)
  {
    int j  ;

    if( l < r ) 
      {
        // divide and conquer
        j = partition( a, l, r);
        quicksort( a, l, j-1);
        quicksort( a, j+1, r);
      }
     printfunc(a) ;
  }



  int partition( int a[], int l, int r) {
    int pivot, i, j, t;
    pivot = a[l];
    i = l; j = r+1;
		
    while( 1)
      {
        do ++i; while( a[i] <= pivot && i <= r );
        do --j; while( a[j] > pivot );
        if( i >= j ) break;
        t = a[i]; a[i] = a[j]; a[j] = t;
      }
    t = a[l]; a[l] = a[j]; a[j] = t;
    return j;
  }


void printfunc(int a[])
{
  int i ;

  printf("\n\nSorted list in ascending order (quicksort):  ");
  for(i = 0; i < 9; ++i)
    printf(" %d ", a[i]);

}  

