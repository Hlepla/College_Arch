/* main.c */

#include <stdio.h>

int quicksort( int array[], int , int) ;
int insertionsort(int array[]) ;
int bubblesort(int array[]);



 int array[] = {7, 12, 1, -2, 0, 15, 4, 11, 9} ;

int main()
{
  int left =0 , right =8 ;

  quicksort(array, left , right) ;
  insertionsort(array);
  bubblesort( array);

  return 0 ;
}
