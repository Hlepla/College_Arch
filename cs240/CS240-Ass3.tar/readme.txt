/* Readme.txt */

NAME:

  msh (my shell)

DESCRIPTION:

  Basic shell that runs various programs and limited shell operations.
  The shell now features history, piping, and file execution.

NOTE: The feature PATH editing is NOT implemented. Alias is implemented but not set up for use. 
      Such features may be implemented in the near future.

INSTALLATION AND EXECUTION:

  To complie source file, type  "gcc msh.c -o msh" without the quotes.
  To run the executable, type "./msh" without the quotes.
  To run the file execution of mshrc, type "read" into the command line
  with out the quotes.

RELEASED VERSIONS:

  V 1.0
  V 1.5
  V 1.75

AUTHOR:

  Created by Hayden Lepla

REPORTING BUGS:

  Report all bugs to lepl1529@vandals.uidaho.edu

COPYRIGHT:

  This is free software: you are free to change and redistribute it.
  There is NO WARRANTY, to the extent permitted by law.
